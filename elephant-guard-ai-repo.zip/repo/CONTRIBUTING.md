# Contributing to ElephantGuard AI

Thank you for your interest in contributing! This project aims to reduce human-elephant conflict through open-source technology. Every contribution — code, data, documentation, or field testing — matters.

## 🌿 Ways to Contribute

- 🐛 **Bug reports** — Open an issue with steps to reproduce
- 💡 **Feature suggestions** — Open a discussion or issue
- 📸 **Training data** — Contribute labelled thermal elephant images
- 🔧 **Code** — Fix bugs, improve ML accuracy, add hardware support
- 📖 **Documentation** — Improve setup guides, translate docs
- 🧪 **Field testing** — Deploy a node and share results

## 🚀 Getting Started

1. **Fork** this repository
2. **Clone** your fork: `git clone https://github.com/YOUR_USERNAME/elephant-guard-ai.git`
3. **Create a branch**: `git checkout -b feature/your-feature-name`
4. **Make your changes** and write tests if applicable
5. **Commit**: `git commit -m "feat: add description of change"`
6. **Push**: `git push origin feature/your-feature-name`
7. **Open a Pull Request** against `main`

## 📋 Commit Message Convention

We follow [Conventional Commits](https://www.conventionalcommits.org/):

```
feat:     New feature
fix:      Bug fix
docs:     Documentation only
style:    Formatting, no logic change
refactor: Code restructure, no behaviour change
test:     Adding or updating tests
chore:    Build process, dependency updates
```

## 🔍 Code Standards

- **Python**: Follow PEP 8, use type hints where practical
- **C/C++**: Follow Arduino style guide for firmware
- **Tests**: Add tests for any new gateway or ML logic
- **Comments**: Explain *why*, not just *what*

## 📸 Contributing Training Data

Labelled thermal elephant images are extremely valuable. If you have access to wildlife cameras or thermal footage:

1. Use [LabelImg](https://github.com/HumanSignal/labelImg) to annotate in YOLO format
2. Classes: `elephant`, `human`, `animal_other`, `vehicle`
3. Open an issue titled "Training data contribution" and we will share an upload link

## ⚖️ Code of Conduct

Be respectful, inclusive, and constructive. This project exists to protect both human lives and wildlife — please bring that spirit to all interactions.

## 📬 Questions?

Open an issue or start a Discussion on GitHub.
